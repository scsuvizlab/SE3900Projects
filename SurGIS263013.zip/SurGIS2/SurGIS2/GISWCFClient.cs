﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * ++++++++++++++++++======  WCF Client Class ============================
 * 
 * 
 * This class will contain all the methodology and communications between the GIS application and the WCF server
 * 
 * The client and server will be responsible for passing object from one instance of the GIS application to another
 * 
 * 
 * 
 * 
 * 
 * */


namespace SurGIS2
{
    class GISWCFClient
    {
    }
}
